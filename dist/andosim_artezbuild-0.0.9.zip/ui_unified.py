import bpy

from . import get_backend


_BACKEND_ANDO = "ANDO"
_BACKEND_PPF = "PPF"


class ANDOSIM_ARTEZBUILD_PT_main(bpy.types.Panel):
    bl_label = "AndoSim ArteZbuild"
    bl_idname = "ANDOSIM_ARTEZBUILD_PT_main"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "AndoSim"

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False

        backend = get_backend(context)
        backend_label = "Ando Core" if backend == _BACKEND_ANDO else "PPF Contact Solver"

        box = layout.box()
        row = box.row(align=True)
        row.label(text="Solver Backend", icon="MOD_PHYSICS")
        row.label(text=backend_label)

        # Note: detailed UI lives in the vendored AndoSim panels (ANDO_PT_*),
        # and in the PPF panel below.


class ANDOSIM_ARTEZBUILD_PT_backend(bpy.types.Panel):
    bl_label = "Backend"
    bl_idname = "ANDOSIM_ARTEZBUILD_PT_backend"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "AndoSim"
    bl_parent_id = "ANDOSIM_ARTEZBUILD_PT_main"

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False

        addon = None
        try:
            addon = context.preferences.addons.get(__package__)
        except Exception:
            addon = None

        if not addon or not getattr(addon, "preferences", None):
            layout.label(text="Add-on preferences not available", icon="ERROR")
            return

        layout.prop(addon.preferences, "solver_backend")


class ANDOSIM_ARTEZBUILD_PT_ppf_panel(bpy.types.Panel):
    bl_label = "PPF"
    bl_idname = "ANDOSIM_ARTEZBUILD_PT_ppf_panel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "AndoSim"
    bl_parent_id = "ANDOSIM_ARTEZBUILD_PT_main"

    @classmethod
    def poll(cls, context):
        return get_backend(context) == _BACKEND_PPF

    def draw(self, context):
        from .ui import _try_import_ppf_backend

        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False

        settings = getattr(context.scene, "andosim_artezbuild", None)
        if settings is None:
            layout.label(text="PPF settings not initialized", icon="ERROR")
            return

        backend_or_exc = _try_import_ppf_backend()
        status = layout.box()
        status.label(text="Backend", icon="SETTINGS")
        if isinstance(backend_or_exc, Exception):
            row = status.row()
            row.alert = True
            row.label(text=f"ppf_cts_backend missing: {backend_or_exc}", icon="ERROR")
        else:
            version = getattr(backend_or_exc, "__version__", "?")
            status.label(text=f"ppf_cts_backend OK: {version}", icon="CHECKMARK")

        def _section(parent, prop_name: str, title: str, icon: str):
            box = parent.box()
            row = box.row(align=True)
            opened = bool(getattr(settings, prop_name, False))
            row.prop(settings, prop_name, text="", emboss=False, icon="TRIA_DOWN" if opened else "TRIA_RIGHT")
            row.label(text=title, icon=icon)
            return box, opened

        realtime_box, realtime_open = _section(layout, "ppf_ui_show_realtime", "Realtime", "TIME")
        if realtime_open:
            controls = realtime_box.row(align=True)
            controls.operator("andosim_artezbuild.ppf_run", text="Run", icon="PLAY")
            controls.operator("andosim_artezbuild.ppf_stop", text="Stop", icon="PAUSE")
            reset_row = controls.row(align=True)
            reset_row.enabled = bool(getattr(settings, "ppf_has_snapshot", False)) and not bool(
                getattr(settings, "ppf_baking", False)
            )
            reset_row.operator("andosim_artezbuild.ppf_reset_simulation", text="Reset Simulation", icon="LOOP_BACK")

        bake_box, bake_open = _section(layout, "ppf_ui_show_bake", "Bake", "FILE_TICK")
        if bake_open:
            bake_box.use_property_split = True
            bake_box.use_property_decorate = False
            bake_box.prop(settings, "auto_export")
            bake_box.prop(settings, "use_selected_colliders")
            bake_box.prop(settings, "scene_path")
            bake_box.prop(settings, "output_dir")
            bake_box.prop(settings, "target_object")
            bake_box.prop(settings, "fps")

            bake = bake_box.row(align=True)
            if bool(getattr(settings, "ppf_baking", False)):
                bake.operator("andosim_artezbuild.ppf_cancel_bake", text="Cancel", icon="CANCEL")
            else:
                bake.operator("andosim_artezbuild.ppf_bake_cache", text="Bake Cache", icon="FILE_TICK")

        settings_box, settings_open = _section(layout, "ppf_ui_show_settings", "Settings", "SETTINGS")
        if settings_open:
            box = settings_box.box()
            box.label(text="Material Preset", icon="MATERIAL")
            box.prop(settings, "ppf_material_preset")

            sim = settings_box.box()
            sim.label(text="Simulation", icon="TIME")
            sim.prop(settings, "dt")
            sim.prop(settings, "solver_fps")
            sim.prop(settings, "gravity")

            shell = settings_box.box()
            shell.label(text="Shell", icon="MOD_CLOTH")
            shell.prop(settings, "tri_model")
            shell.prop(settings, "tri_density")
            shell.prop(settings, "tri_young_mod")
            shell.prop(settings, "tri_poiss_rat")
            shell.prop(settings, "tri_bend")
            shell.prop(settings, "tri_shrink")
            shell.prop(settings, "tri_contact_gap")
            shell.prop(settings, "tri_contact_offset")
            shell.prop(settings, "tri_strain_limit")
            shell.prop(settings, "tri_friction")

            stat = settings_box.box()
            stat.label(text="Static Collider", icon="CUBE")
            stat.prop(settings, "static_contact_gap")
            stat.prop(settings, "static_contact_offset")
            stat.prop(settings, "static_friction")

            obj = context.object
            obj_box = settings_box.box()
            obj_box.label(text="Active Object", icon="OUTLINER_OB_MESH")
            if obj is None:
                obj_box.label(text="Select a mesh object to edit PPF role/pins", icon="INFO")
                return
            if obj.type != "MESH":
                obj_box.label(text=f"Active object '{obj.name}' is not a mesh", icon="INFO")
                return

            props = getattr(obj, "andosim_artezbuild", None)
            if props is None:
                obj_box.label(text="Object settings not initialized", icon="ERROR")
                return

            col = obj_box.column(align=True)
            col.prop(props, "enabled")
            row = col.row(align=True)
            row.enabled = bool(getattr(props, "enabled", False))
            row.prop(props, "role")

            if not bool(getattr(props, "enabled", False)) or getattr(props, "role", "IGNORE") == "IGNORE":
                obj_box.label(text="Enable the object to include it in export", icon="INFO")
                return

            role = getattr(props, "role", "DEFORMABLE")

            # Per-object overrides
            obj_box.separator()
            obj_box.prop(props, "use_object_params")
            if bool(getattr(props, "use_object_params", False)):
                if role == "DEFORMABLE":
                    o = obj_box.box()
                    o.label(text="Deformable Override", icon="MOD_CLOTH")
                    o.prop(props, "tri_model")
                    o.prop(props, "tri_density")
                    o.prop(props, "tri_young_mod")
                    o.prop(props, "tri_poiss_rat")
                    o.prop(props, "tri_bend")
                    o.prop(props, "tri_shrink")
                    o.prop(props, "tri_contact_gap")
                    o.prop(props, "tri_contact_offset")
                    o.prop(props, "tri_strain_limit")
                    o.prop(props, "tri_friction")
                elif role == "STATIC_COLLIDER":
                    o = obj_box.box()
                    o.label(text="Static Collider Override", icon="CUBE")
                    o.prop(props, "static_contact_gap")
                    o.prop(props, "static_contact_offset")
                    o.prop(props, "static_friction")

            # Pins / stitches only apply to deformables.
            if role == "DEFORMABLE":
                pins = obj_box.box()
                pins.label(text="Pins", icon="PINNED")
                row = pins.row(align=True)
                row.operator("andosim_artezbuild.ppf_create_pin_handle", text="Create Pin Handle")
                row.operator("andosim_artezbuild.ppf_clear_grab", text="Clear Handles")
                pins.prop(props, "pin_enabled")
                if bool(getattr(props, "pin_enabled", False)):
                    pins.prop(props, "pin_vertex_group")
                    pins.prop(props, "pin_pull_strength")

                pins.separator(factor=0.5)
                pins.prop(props, "attach_enabled")
                if bool(getattr(props, "attach_enabled", False)):
                    pins.prop(props, "attach_target_object")
                    pins.prop(props, "attach_vertex_group")
                    pins.prop(props, "attach_pull_strength")

                stitch = obj_box.box()
                stitch.label(text="Stitches", icon="LINKED")
                stitch.prop(props, "stitch_enabled")
                if bool(getattr(props, "stitch_enabled", False)):
                    stitch.prop(props, "stitch_target_object")
                    stitch.prop(props, "stitch_source_vertex_group")
                    stitch.prop(props, "stitch_target_vertex_group")
                    stitch.prop(props, "stitch_max_distance")


_classes = (
    ANDOSIM_ARTEZBUILD_PT_main,
    ANDOSIM_ARTEZBUILD_PT_backend,
    ANDOSIM_ARTEZBUILD_PT_ppf_panel,
)


def register():
    for cls in _classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(_classes):
        bpy.utils.unregister_class(cls)
